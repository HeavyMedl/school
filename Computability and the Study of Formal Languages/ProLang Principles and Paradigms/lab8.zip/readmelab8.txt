LAB 8 Completed CLite Parser

I have significantly altered my approach to the conjunction(), relation(),.. codes and have modified my display method to take ints.  Should properly Parser and display the abstract syntax of a given Clite script. 
