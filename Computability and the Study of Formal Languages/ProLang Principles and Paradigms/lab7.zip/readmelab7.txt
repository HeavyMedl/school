LAB 7

Modified code or declaration and declarations.  Added the pre-emptive "add" method for arraylist representation of declarations.

Added a display() method in the declaration class.  
