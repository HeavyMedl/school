int main true false >= <= ! !=  > = < == bool char else false float if int main true while = || && == != < <= > >= + - * / ! [ ] ; , { } ( ) //
