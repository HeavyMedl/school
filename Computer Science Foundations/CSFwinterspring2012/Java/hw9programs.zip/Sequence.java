public interface Sequence
{
  int next();
  boolean hasNext();
}