int main() { a = 5 }
