public class IceCreamConeTester
{
  public static void main(String[] args)
  {
    IceCreamCone vanilla = new IceCreamCone();
    
    System.out.println("Surface Area:  " + vanilla.getSurfaceArea());
    System.out.println("Volume:  " + vanilla.getVolume());
  }
}
