LAB 6

I've created a indent class that is to be used in the display method of the abstact syntax of the Parser.  I've included that file + the AbstractSyntax.java file.
