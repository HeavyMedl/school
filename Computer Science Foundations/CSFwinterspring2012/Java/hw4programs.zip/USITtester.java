public class USITtester
{
  public static void main(String[] args)
  {
    USIncomeTax1913 mytax = new USIncomeTax1913(600000);
    System.out.println("Your Tax: " + mytax.calculateTax());
  }
}