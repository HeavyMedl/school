LEXER -- COMPILING AND RUNNING

The lexer will consume characters sequentially and convert predefined values into lexemes by which the parser uses.

COMPILING

In a terminal, navigate to the directory that contains the lexer. Use the compile command

	javac Lexer.java

which will subsequently produce java class file Lexer.class

Your Lexer is now ready to be used on Clite scripts.

RUNNING

When you're ready to use the Lexer on a Clite script, use the command..

	java Lexer <myfile>.cpp

where <myfile>.cpp represents the Clite file to be analyzed.  Although the lexer will convert any file into the list of Clite lexemes; it should be noted that its purpose is to convert .cpp files, as this is the Clite program script extension.
